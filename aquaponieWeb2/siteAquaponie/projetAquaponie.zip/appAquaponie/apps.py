from django.apps import AppConfig


class AppaquaponieConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appAquaponie'
